import React from 'react';
import { Link } from 'react-router-dom';
import './product.css';
export default function Productlist () {

  return (
    <>
      {/* Hero Section */}
      <section id="Product" className="py-5 text-center container bg-light border-bottom">
        <div className="row py-5">
          <div className="col-lg-8 col-md-10 mx-auto">
            <h1 className="fw-bold text-primary display-5">📚 Koleksi Buku Unggulan</h1>
            <p className="lead text-muted mt-3">
              Jelajahi ribuan buku pilihan dari berbagai kategori. Temukan bacaan favoritmu untuk menambah wawasan dan hiburan.
            </p>
            <div className="d-flex justify-content-center mt-4">
              <a href="#produk" className="btn btn-primary m-2 px-4">
                Lihat Koleksi
              </a>
              <a href="#kontak" className="btn btn-outline-primary m-2 px-4">
                Hubungi Kami
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Product List */}
      <div className="album py-5 bg-white">
        <div className="container">
          <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
            {[1, 2, 3, 4, 5, 6].map((item, index) => (
              <div className="col" key={index}>
                <div className="card shadow-sm h-100 book-card">
                  <img
                    src={`https://picsum.photos/300/200?random=${item}`}
                    className="card-img-top"
                    alt="Cover Buku"
                    style={{ objectFit: 'cover', height: '200px' }}
                  />
                  <div className="card-body">
                    <h5 className="card-title fw-semibold">Judul Buku #{item}</h5>
                    <p className="card-text text-muted mb-1">Penulis: John Doe</p>
                    <p className="text-secondary small mb-3">Kategori: Fiksi | Tahun: 2023</p>
                    <p className="card-text small">Deskripsi singkat buku yang bisa membuat pembaca penasaran dan tertarik untuk membaca lebih lanjut.</p>
                    <div className="d-flex justify-content-between align-items-center mt-3">
                      <div className="btn-group">
                        <button type="button" className="btn btn-sm btn-outline-primary">Detail</button>
                        <button type="button" className="btn btn-sm btn-outline-success">Pinjam</button>
                      </div>
                      <small className="text-muted">Tersedia</small>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
