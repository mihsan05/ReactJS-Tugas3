export default function Footer() {
    return(
        <>

{/*Footer*/}
<footer>
      <div className="bg-dark text-secondary px-4 py-1 text-center">
        <div className="py-3">
          <div className="mx-auto" style={{ maxWidth: '1200px' }}>
            <h2 className="fs-5 mb-2 text-white">NF ACADEMY - MUHAMAD IHSAN - XANNPEDIA.</h2>
            <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
              {/* Tambahkan link atau elemen lain jika diperlukan */}
            </div>
          </div>
        </div>
      </div>
    </footer>
        </>
    )
}