export default function Contact() {
    return(
        <>
{/* Contact Me */}
<div id="Contact" className="container-fluid my-5">
  <div className="row justify-content-center align-items-center">
    <div className="col-md-10">
      <div className="p-4 rounded-4 shadow-lg" style={{ 
        background: 'rgba(255, 255, 255, 0.75)', 
        backdropFilter: 'blur(10px)', 
        WebkitBackdropFilter: 'blur(10px)', 
        border: '1px solid rgba(255, 255, 255, 0.3)' 
      }}>
        <div className="row">
          {/* Left side - form */}
          <div className="col-md-6 px-4 py-3">
            <h2 className="fw-bold text-primary mb-3">
              <i className="bi bi-chat-dots-fill me-2"></i>Hubungi Kami
            </h2>
            <p className="text-muted">
              Ada yang ingin kamu sampaikan? Kami siap mendengarkan!
            </p>
            <form>
              <div className="mb-3">
                <label htmlFor="name" className="form-label fw-semibold">Nama</label>
                <div className="input-group">
                  <span className="input-group-text"><i className="bi bi-person-fill"></i></span>
                  <input type="text" className="form-control" id="name" placeholder="Namamu siapa?" />
                </div>
              </div>
              <div className="mb-3">
                <label htmlFor="email" className="form-label fw-semibold">Email</label>
                <div className="input-group">
                  <span className="input-group-text"><i className="bi bi-envelope-fill"></i></span>
                  <input type="email" className="form-control" id="email" placeholder="Email aktifmu" />
                </div>
              </div>
              <div className="mb-3">
                <label htmlFor="message" className="form-label fw-semibold">Pesan</label>
                <textarea className="form-control" id="message" rows="4" placeholder="Ketik pesanmu di sini..."></textarea>
              </div>
              <button type="submit" className="btn btn-success fw-bold px-4">
                <i className="bi bi-send-fill me-1"></i>Kirim
              </button>
            </form>
          </div>

          {/* Right side - image & info */}
          <div className="col-md-6 text-center d-flex flex-column justify-content-center p-4">
            <img 
              src="https://picsum.photos/600/400?grayscale" 
              alt="Ilustrasi Kontak" 
              className="img-fluid rounded-3 mb-3 shadow-sm"
            />
            <p className="text-muted">📍 Perpustakaan Xannpedia<br />Jl. Literasi No. 42, Book City</p>
            <p className="text-muted">📞 0812-3456-7890<br />✉️ info@xannpedia.com</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

        </>
    )
}