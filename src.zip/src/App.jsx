import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from "./components/shared/Header";
import Footer from "./components/shared/Footer";
import Hero from "./components/shared/Hero";
import Productlist from "./components/shared/Productlist";
import Team from "./components/shared/Team";
import Contact from "./components/shared/Contact";

import Home from "./Book/Home";
import Book from "./Book/book";


function App() {
  return (
    <Router>
      <div className="container">
        <Header />

        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <Productlist />
              <Team />
              <Contact />
            </>
          } />

{/* ✅ Halaman Home Buku */}
          <Route path="/home" element={<Home />} />

          {/* ✅ Halaman Book */}
          <Route path="/book" element={<Book />} />



          {/* 🔹 Halaman khusus Team */}
          <Route path="/product" element={<Productlist />} />
          
          {/* 🔹 Halaman khusus Team */}
          <Route path="/team" element={<Team />} />

          {/* 🔹 Halaman khusus Contact */}
          <Route path="/contact" element={<Contact />} />
        </Routes>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
